package com.example.alunos.listaalunos;

public class Aluno {
    private int id;
    private String nomeAluno;
    private double media;

    public String getNomeAluno(){
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno){
        this.nomeAluno = nomeAluno;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return nomeAluno + "            " + "\nMédia Final: " +
                String.format("%.1f", media);
    }
}
