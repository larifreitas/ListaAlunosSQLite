package com.example.alunos.listaalunos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ListaOpenHelper extends SQLiteOpenHelper {
    public ListaOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE listaAlunos (" +
                "_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                "nomeAluno TEXT NOT NULL," +
                "mediaAluno INTEGER" +
                ")";
        sqLiteDatabase.execSQL(sql);

        sql = "INSERT INTO listaAlunos (nomeAluno, mediaAluno) " +
                " VALUES ('Maria', 10)";
        sqLiteDatabase.execSQL(sql);

        sql = "INSERT INTO listaAlunos (nomeAluno, mediaAluno) " +
                " VALUES ('João', 9.5)";
        sqLiteDatabase.execSQL(sql);

        sql = "INSERT INTO listaAlunos (nomeAluno, mediaAluno) " +
                " VALUES ('Henrique', 6.75)";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }
}
