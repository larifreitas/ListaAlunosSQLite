package com.example.alunos.listaalunos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DAO {
    private ListaOpenHelper openHelper;
    private SQLiteDatabase sqLiteDatabase;

    public DAO(Context context) {
        openHelper = new ListaOpenHelper(context, "listaAlunos.db",
                null, 1);
    }

    private void abrir() {
        sqLiteDatabase = openHelper.getWritableDatabase();
    }

    private void fechar() {
        if (sqLiteDatabase != null) sqLiteDatabase.close();
    }

    public ArrayList<Aluno> consultarAluno() {
        abrir();
        ArrayList<Aluno> alunos = new ArrayList<>();

        Cursor cursor = sqLiteDatabase.query("listaAlunos",
                null, null, null,
                null, null, "nomeAluno");
        while (cursor.moveToNext()) {
            Aluno aluno = new Aluno();
            aluno.setId(cursor.getInt(0));
            aluno.setNomeAluno(cursor.getString(1));
            aluno.setMedia(cursor.getInt(2));
            alunos.add(aluno);
        }
        fechar();
        return alunos;
    }

    public void incluirAluno(Aluno aluno) {
        abrir();
        ContentValues values = new ContentValues();
        values.put("nomeAluno", aluno.getNomeAluno());
        // Mesma coisa, só que agora para o campo "quantidade"
        values.put("mediaAluno", aluno.getMedia());
        sqLiteDatabase.insert("listaAlunos", null, values);
        fechar();
    }

    public void excluirAluno(Aluno aluno) {
        abrir();
        sqLiteDatabase.delete("listaAlunos", "_id = " +
                aluno.getId(), null);
        fechar();
    }
}
