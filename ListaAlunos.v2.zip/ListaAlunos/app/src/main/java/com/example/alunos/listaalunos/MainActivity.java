package com.example.alunos.listaalunos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Aluno> alunos = new ArrayList<>();
    private ArrayAdapter<Aluno> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final DAO dao = new DAO(this);
        alunos = dao.consultarAluno();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, alunos);
        ListView listView = (ListView)findViewById(R.id.listView);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                alunos.remove(i);
                adapter.notifyDataSetChanged();
            }
        });
    }


    public void adicionar(View view) {
        EditText edtNome = findViewById(R.id.edtNome);
        EditText edtMedia = findViewById(R.id.edtMedia);

        String nome = edtNome.getText().toString();
        String media = edtMedia.getText().toString();

        if (nome.isEmpty() || media.isEmpty()) {
            Toast.makeText(this, "Forneça todos os dados!", Toast.LENGTH_LONG).show();
            } else {
            Aluno aluno = new Aluno();
            aluno.setNomeAluno(nome);
            aluno.setMedia(Double.parseDouble(media));
            alunos.add(aluno);
            DAO dao = new DAO(this);
            dao.incluirAluno(aluno);
            adapter.notifyDataSetChanged();
            edtNome.setText("");
            edtMedia.setText("");
            edtNome.requestFocus();
        }
    }
}
